import { TestBed } from '@angular/core/testing';

import { CrmServiceService } from './crm-service.service';

describe('CrmServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CrmServiceService = TestBed.get(CrmServiceService);
    expect(service).toBeTruthy();
  });
});
