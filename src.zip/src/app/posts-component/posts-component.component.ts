import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormGroup, FormControl } from '@angular/forms';
import { CrmServiceService } from '../services/crm-service.service';

@Component({
  selector: 'posts-component',
  templateUrl: './posts-component.component.html',
  styleUrls: ['./posts-component.component.css']
})
export class PostsComponentComponent implements OnInit {
  employees;
  private url = 'http://localhost:8080/api/employees';
  employeeForm = new FormGroup({
    firstName: new FormControl(),
    lastName: new FormControl(),
    email: new FormControl(),
  });
  constructor(private crmServiceService: CrmServiceService) {

  }

  ngOnInit() {
    this.crmServiceService.getEmployee()
      .subscribe(
        response => {
          this.employees = response;
          console.log(this.employees);
        }, error => {
          alert('An unexpected error occured');
          console.log(error);
        });


  }

  addEmployee() {
    console.log(this.employeeForm.value);
    this.crmServiceService.addEmployee(this.employeeForm.value).subscribe(
      response => {
        console.log(response);
        this.employees.push(response);
      }, error => {
        alert('An unexpected error occured');
        console.log(error);
      });

  }

  deleteEmployee(id) {
    let deleteUrl = this.url + '/' + id;
    this.crmServiceService.deleteEmployee(id).subscribe(
      response => {
        console.log(deleteUrl);
        console.log(response);
      }, (error: Response) => {
        if (error.status === 404) {
          alert('This post has been already deleted');
        }
        alert('An unexpected error occured');
        console.log(error);
      });
  }

}
