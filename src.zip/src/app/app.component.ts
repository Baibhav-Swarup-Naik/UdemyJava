import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'hello-world';

  Post = {
    isFavourite: true,
  }

  onFavouriteChange(eventArgs) {
    console.log('Change detected in favourite component: ',eventArgs);
  }

}
