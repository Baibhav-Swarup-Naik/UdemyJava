import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ng-for',
  templateUrl: './ng-for.component.html',
  styleUrls: ['./ng-for.component.css']
})
export class NgForComponent implements OnInit {

  courses = [];

  constructor() { }

  ngOnInit() {
  }

  onAdd() {
    this.courses.push({ id: 5, name: 'name5' })
  }
  onRemove(course) {
    const index = this.courses.indexOf(course);
    this.courses.splice(index, 1);
  }
  loadCourses() {
    this.courses = [
      { id: 1, name: 'name1' },
      { id: 2, name: 'name2' },
      { id: 3, name: 'name3' },
      { id: 4, name: 'name4' },
    ];
  }

  trackCourse(index, course) {
    return course ? course.id : undefined;
  }

}
