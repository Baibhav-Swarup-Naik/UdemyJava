import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContactFormComponent } from './contact-form/contact-form.component';
import { CoursesComponent } from './courses.component';
import { CourseComponent } from './course/course.component';
import { FavoriteComponent } from './favorite/favorite.component';
import { NewCourseFormComponent } from './new-course-form/new-course-form.component';
import { NgForComponent } from './ng-for/ng-for.component';
import { PanelComponent } from './panel/panel.component';
import { PostsComponentComponent } from './posts-component/posts-component.component';
import { SafeTraversalComponent } from './safe-traversal/safe-traversal.component';
import { SignupFormComponent } from './signup-form/signup-form.component';
import { SwitchCaseComponent } from './switch-case/switch-case.component';

const routes: Routes = [
  {
    path: '',
    component: CoursesComponent
  },
  {
    path: 'contactForm',
    component: ContactFormComponent
  },
  {
    path: 'course',
    component: CourseComponent
  },
  {
    path: 'ngFor',
    component: NgForComponent
  },
  {
    path: 'posts',
    component: PostsComponentComponent
  },
  {
    path: 'safeTraversal',
    component: SafeTraversalComponent
  },
  {
    path: 'signUp',
    component: SignupFormComponent
  },
  {
    path: 'switchCase',
    component: SwitchCaseComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
