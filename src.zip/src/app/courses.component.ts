
import { Component } from '@angular/core';
import { CoursesService } from './courses.service';

@Component({
    selector: 'courses',
    template: `<h2>{{title}}</h2>
    <h2 [textContent]="title"></h2>
        <ul>
            <li *ngFor="let course of courses">{{course}}</li>
        </ul>
        <table>
        <tr>
        <td [attr.colspan]="colSpan"></td>
        </tr>
        </table>
<button class="btn btn-primary" (click)="onSave($event)">Save</button>
<input (keyup)="onKeyUp($event)" />
<br>
<input (keyup.enter)="onKeyUp1()" />
<br>
<input #email (keyup.enter)="onKeyUp2(email.value)" />
<br>
<input [value]="email1" (keyup.enter)="email1 = $event.target.value; onKeyUp3()" />
<br>
<input [(ngModel)]="email1" (keyup.enter)="onKeyUp3()" />
<br>
{{course.title | uppercase}}<br>
{{course.students | number}}<br>
{{course.rating | number:'1.2-2'}}<br>
{{course.price | currency:'AUD':true:'3.2-2'}}<br>
{{course.releaseDate | date:'shortDate'}}
<br><br>
{{text | summary:10}}


    `,
    //  providers: [CoursesService],
})
export class CoursesComponent {
    title = 'List of Courses';
    courses;
    colspan = 2;
    email1 = 'abcd@ryu.com';
    course = {
        title: 'Title of Pipe',
        rating: 4.9786,
        students: 63726,
        price: 190.34,
        releaseDate: new Date(2020, 5, 1),
    }
    text = `dkhakajfkanf dudua adada adbadajx aduadb ajdha aua a jhaia aad 
    dkhakajfkanf dudua adada adbadajx aduadb ajdha aua a jhaia aad
    dkhakajfkanf dudua adada adbadajx aduadb ajdha aua a jhaia aad
    dkhakajfkanf dudua adada adbadajx aduadb ajdha aua a jhaia aad `;
    constructor(private service: CoursesService) {
        // let service = new CoursesService();
        this.courses = service.gtCourses();
    }
    onSave($event) {
        console.log('button clicked');
        console.log($event);
    }
    onKeyUp($event) {
        console.log('key up');
        if ($event.keyCode === 13) {
            console.log('Enter was pressed');
            console.log($event);
        }
    }
    onKeyUp1() {
        console.log('key up enter');
    }
    onKeyUp2(email) {
        console.log(email);
    }
    onKeyUp3() {
        console.log(this.email1);

    }
}
