import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-safe-traversal',
  templateUrl: './safe-traversal.component.html',
  styleUrls: ['./safe-traversal.component.css']
})
export class SafeTraversalComponent implements OnInit {

task = {
  title: 'Review application',
 /*  assignee : {
    name: 'Baibhav'
  } */ /* this situation is handeled by afe traversal in template if assignee is undefined */
}

  constructor() { }

  ngOnInit() {
  }

}
