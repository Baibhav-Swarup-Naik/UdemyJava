
export class CoursesService {
    gtCourses() {
        return ['course1', 'course2', 'course3'];
    }
}