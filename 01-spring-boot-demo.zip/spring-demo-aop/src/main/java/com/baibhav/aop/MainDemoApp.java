package com.baibhav.aop;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.baibhav.aop.dao.AccountDAO;
import com.baibhav.aop.dao.MembershipDAO;

public class MainDemoApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(DemoConfig.class);
		AccountDAO accountDAO = context.getBean("accountDAO",AccountDAO.class);
		accountDAO.addAccount();
		System.out.println("Calling add account once again");
		accountDAO.addAccount(new Account(),true);
		MembershipDAO membershipDAO = context.getBean("membershipDAO",MembershipDAO.class);
		membershipDAO.addAccount();
		membershipDAO.addSillyAccount();
		membershipDAO.removeAccount();
		context.close();
		
	}

}
