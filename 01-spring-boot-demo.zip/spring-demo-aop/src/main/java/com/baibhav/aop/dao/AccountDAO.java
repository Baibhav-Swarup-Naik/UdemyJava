package com.baibhav.aop.dao;

import org.springframework.stereotype.Component;

import com.baibhav.aop.Account;

@Component
public class AccountDAO {

	public void addAccount() {
		System.out.println(getClass()+"Doing add Account DB ativity ");
	}
	
	public void addAccount(Account account, boolean flag) {
		System.out.println(getClass()+"Doing add Account DB ativity with parameter Account ");
	}
}
