package com.baibhav.aop.dao;

import org.springframework.stereotype.Component;

@Component
public class MembershipDAO {

	public void addAccount() {
		System.out.println(getClass()+"Doing add Account DB ativity ");
	}
	
	public boolean addSillyAccount() {
		System.out.println(getClass()+"Doing add Account DB ativity in addSillyAccount()");
		return true;
	}
	public boolean removeAccount() {
		System.out.println(getClass()+"Doing add Account DB ativity in removeAccount()");
		return true;
	}
}
