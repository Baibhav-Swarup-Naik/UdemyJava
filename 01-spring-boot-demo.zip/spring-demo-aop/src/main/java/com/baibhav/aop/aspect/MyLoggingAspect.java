package com.baibhav.aop.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class MyLoggingAspect {

	
	@Pointcut("execution (* com.baibhav.aop.dao.*.*(..))")
	private void forDaoPackage() {}
	

	@Before("forDaoPackage()")
	public void beforeAddAccountAdvice() {
	System.out.println("\n===> Executing the @before advice on AddAccount()");	
	}
	
	@Before("forDaoPackage()")
	public void performApiAnalytics() {
	System.out.println("\n===> performApiAnalytics");	
	}
	
}
