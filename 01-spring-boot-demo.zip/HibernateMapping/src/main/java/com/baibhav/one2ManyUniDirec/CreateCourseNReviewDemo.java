package com.baibhav.one2ManyUniDirec;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class CreateCourseNReviewDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml")
				.addAnnotatedClass(Instructor.class).addAnnotatedClass(InstructorDetail.class)
				.addAnnotatedClass(Course.class).addAnnotatedClass(Review.class).buildSessionFactory();
		try {
			Session session = sessionFactory.getCurrentSession();
			session.beginTransaction();
			
			Course course = new Course("spring");
			
			Review r1 = new Review("Review 1");
			Review r2 = new Review("Review 2");
			Review r3 = new Review("Review 3");
			
			course.addReview(r1);
			course.addReview(r2);
			course.addReview(r3);
			session.save(course);
			session.getTransaction().commit();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
