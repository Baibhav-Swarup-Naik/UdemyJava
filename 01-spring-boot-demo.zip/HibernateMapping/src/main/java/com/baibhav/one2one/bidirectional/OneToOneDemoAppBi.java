package com.baibhav.one2one.bidirectional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class OneToOneDemoAppBi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml")
				.addAnnotatedClass(InstructorBi.class).addAnnotatedClass(InstructorDetailBi.class)
				.buildSessionFactory();
		try {
			Session session = sessionFactory.getCurrentSession();

			session.beginTransaction();
			int id = 232;

			InstructorDetailBi instructorDetail = session.get(InstructorDetailBi.class, id);
			System.out.println("instructor from detail : "+instructorDetail.getInstructur());

			session.getTransaction().commit();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
