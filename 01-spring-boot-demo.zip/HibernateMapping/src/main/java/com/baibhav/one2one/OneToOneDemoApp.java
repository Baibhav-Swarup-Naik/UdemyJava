package com.baibhav.one2one;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class OneToOneDemoApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml")
				.addAnnotatedClass(Instructor.class).addAnnotatedClass(InstructorDetail.class).buildSessionFactory();
		try {
			Session session = sessionFactory.getCurrentSession();
			Instructor instructor = new Instructor("Baibhav", "Naik", "abc@gmail.com");
			
			InstructorDetail instructorDetail = new InstructorDetail("youtube url", "coding");
			instructor.setInstructorDetail(instructorDetail);
			
			
			session.beginTransaction();
		//	session.save(instructor);
			session.persist(instructor);
			session.getTransaction().commit();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
