package com.baibhav.many2many;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class ManyToManyDemoApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml")
				.addAnnotatedClass(Instructor.class).addAnnotatedClass(InstructorDetail.class)
				.addAnnotatedClass(Course.class).addAnnotatedClass(Student.class).addAnnotatedClass(Review.class)
				.buildSessionFactory();
		try {
			Session session = sessionFactory.getCurrentSession();
			session.beginTransaction();
			Course course1 = new Course("datastructure");
			session.save(course1);
			/*
			 * Course course2 = new Course("java"); Course course3 = new Course("c++");
			 */

			Student student1 = new Student("abc", "def", "abcdef@gmail.com");
			Student student2 = new Student("pqr", "stu", "pqrstu@gmail.com");
			course1.addStudent(student1);
			course1.addStudent(student2);
			session.save(student1);
			session.save(student2);
			session.getTransaction().commit();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
