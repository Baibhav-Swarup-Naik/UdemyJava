package com.baibhav.one2many;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class OneToManyDemoApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml")
				.addAnnotatedClass(Instructor.class).addAnnotatedClass(InstructorDetail.class)
				.addAnnotatedClass(Course.class).buildSessionFactory();
		try {
			Session session = sessionFactory.getCurrentSession();
			Instructor instructor = new Instructor("Itisha", "Shrivastava", "abc@gmail.com");

			InstructorDetail instructorDetail = new InstructorDetail("youtube url", "coding");
			instructor.setInstructorDetail(instructorDetail);
			
		Course course1 = new Course("Music");
		Course course2 = new Course("Dance");
		Course course3 = new Course("Play");

		instructor.addCourse(course1);
		instructor.addCourse(course2);
		instructor.addCourse(course3);
			session.beginTransaction();
			//While using save use the below code or else use persist instead
	/*		session.save(course1);
			session.save(course2);
			session.save(course3);
			session.save(instructorDetail);
			session.save(instructor);*/
			session.persist(instructor);
			session.getTransaction().commit();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
