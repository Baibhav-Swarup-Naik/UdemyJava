package com.baibhav.eagerVsLazy;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class FetchJoinDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml")
				.addAnnotatedClass(Instructor.class).addAnnotatedClass(InstructorDetail.class)
				.addAnnotatedClass(Course.class).buildSessionFactory();
		try {
			Session session = sessionFactory.getCurrentSession();
			int id = 14;
			session.beginTransaction();

			Query<Instructor> query = session
					.createQuery("select i from Instructor i JOIN  FETCH i.courses where i.id=:id", Instructor.class);
			query.setParameter("id", id);
			Instructor instructor = query.getSingleResult();
			System.out.println("Instructor: "+instructor);
			System.out.println("Courses: "+instructor.getCourses());
			session.getTransaction().commit();
			session.close();
			System.out.println("Courses after closing session: "+instructor.getCourses());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
