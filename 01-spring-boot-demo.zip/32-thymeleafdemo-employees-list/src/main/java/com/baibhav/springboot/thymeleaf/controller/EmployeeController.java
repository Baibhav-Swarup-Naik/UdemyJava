package com.baibhav.springboot.thymeleaf.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.baibhav.springboot.thymeleaf.model.Employee;

@Controller
@RequestMapping("/employees")
public class EmployeeController {
	
	//load employee data
	private List<Employee> employees;
	@PostConstruct
	private void loadData() {
		employees = new ArrayList<Employee>();
		Employee emp1 = new Employee(1, "Lesie", "Andrews", "lasie@gmail.com");
		Employee emp2 = new Employee(1, "Lesie", "Andrews", "lasie@gmail.com");
		Employee emp3 = new Employee(1, "Lesie", "Andrews", "lasie@gmail.com");
		Employee emp4 = new Employee(1, "Lesie", "Andrews", "lasie@gmail.com");
		employees.add(emp1);
		employees.add(emp2);
		employees.add(emp3);
		employees.add(emp4);
	}
	
	@GetMapping("/list")
	public String listEmployees(Model model) {
		model.addAttribute("employees", employees);
		return "list-employees";
	}
}
