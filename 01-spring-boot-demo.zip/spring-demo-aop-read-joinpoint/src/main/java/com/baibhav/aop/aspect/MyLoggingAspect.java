package com.baibhav.aop.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.baibhav.aop.Account;

@Aspect
@Order(2)
@Component
public class MyLoggingAspect {


	@Before("com.baibhav.aop.aspect.PointcutExpressionUtility.forDaoPackageNoGetterSetter()")
	public void beforeAddAccountAdvice(JoinPoint theJoinPoint) {
	System.out.println("\n===> Executing the @before advice on AddAccount()");	
	//Display the method signatue
	MethodSignature methodSig = (MethodSignature) theJoinPoint.getSignature();
	System.out.println("Method = "+methodSig);
	
	//display the method argument
	Object args[] = theJoinPoint.getArgs();
	
	for(Object tempArg : args) {
		System.out.println(tempArg);
		if(tempArg instanceof Account) {
			Account theAccount = (Account) tempArg;
			System.out.println("Account anme: "+theAccount.getName());
			System.out.println("Account level: "+theAccount.getLevel());
		}
	}
	}
	
	
	
	
}
