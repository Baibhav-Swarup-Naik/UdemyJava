package com.baibhav.aop;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.baibhav.aop.dao.AccountDAO;
import com.baibhav.aop.dao.MembershipDAO;

public class MainDemoApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(DemoConfig.class);
		AccountDAO accountDAO = context.getBean("accountDAO",AccountDAO.class);
		Account account  = new Account();
		account.setName("MyAccount");
		account.setLevel("MyLevel");
		accountDAO.addAccount(account, true);
		accountDAO.setName("abc");
		accountDAO.getName();
		accountDAO.setServiceCode("abc service");
		accountDAO.getServiceCode();
		MembershipDAO membershipDAO = context.getBean("membershipDAO",MembershipDAO.class);
		membershipDAO.removeAccount();
		context.close();
		
	}

}
