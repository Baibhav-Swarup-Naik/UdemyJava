package com.baibhav;

import java.io.File;

import com.fasterxml.jackson.databind.ObjectMapper;

public class Driver {

	public static void main(String[] args) {
		
		try {
			
			//create object mapper
			ObjectMapper mapper  = new ObjectMapper();
			
			//read json file and cnvert to POJO
			Student student = mapper.readValue(new File("data/sample-full.json"), Student.class);
			
			
			//print first and last name and other data
			System.out.println("FIrst name: "+student.getFirstName());
			System.out.println("Last name: "+student.getLastName());
			
			Address address = student.getAddress();
			System.out.println("Street is: "+address.getStreet());
			System.out.println("City is: "+address.getCity());
			
			for(String language : student.getLanguages()) {
				System.out.println(language);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
}
