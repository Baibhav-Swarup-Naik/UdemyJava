package com.baibhav;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class DeleteStudentDemo {

	public static void main(String[] args) {
		SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml")
				.addAnnotatedClass(Student.class).buildSessionFactory();
		
		Session session = sessionFactory.getCurrentSession();
		try {
			//Fetch data from DB
			
			int studentId=12;
			session.beginTransaction();
			Student myStudent = session.get(Student.class, studentId);
			session.delete(myStudent);
			session.createQuery("delete Student where id='13'").executeUpdate();
			session.getTransaction().commit();
			System.out.println("Done");
			
			
		} catch (Exception e) {
		e.printStackTrace();	
		} finally {
			session.close();
		}

	}

	private static void displayStudents(List<Student> studentsList) {
		studentsList.forEach(s -> {
			System.out.println(s.toString());
		});
	}

}
