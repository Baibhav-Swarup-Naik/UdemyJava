package com.baibhav;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class CreateQueryStudentDemo {

	public static void main(String[] args) {
		SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml")
				.addAnnotatedClass(Student.class).buildSessionFactory();
		
		Session session = sessionFactory.getCurrentSession();
		try {
			
			Student s1 = new Student("Santosh","Kumar","abc@gmain.com");
			Student s2 = new Student("Sagar","Mahapatra","abc@gmain.com");
			Student s3 = new Student("Nasrul","Bharathi","abc@gmain.com");
			session.beginTransaction();
			session.save(s1);
			session.save(s2);
			session.save(s3);
			session.getTransaction().commit();
			System.out.println("Done");
			
			//Fetch data from DB
			
			session = sessionFactory.getCurrentSession();
			session.beginTransaction();
			Student myStudent = session.get(Student.class, s1.getId());
			System.out.println("the require student is: "+myStudent.toString());
			session.getTransaction().commit();
			
			
			
		} catch (Exception e) {
		e.printStackTrace();	
		} finally {
			session.close();
		}

	}

}
