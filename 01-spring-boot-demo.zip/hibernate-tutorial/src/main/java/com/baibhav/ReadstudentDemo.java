package com.baibhav;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class ReadstudentDemo {

	public static void main(String[] args) {
		SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml")
				.addAnnotatedClass(Student.class).buildSessionFactory();
		
		Session session = sessionFactory.getCurrentSession();
		try {
			//Fetch data from DB
			
			session = sessionFactory.getCurrentSession();
			session.beginTransaction();
			
			List<Student> studentsList = session.createQuery("from Student").getResultList();
			displayStudents(studentsList);
			studentsList = session.createQuery("from Student s where s.lastName='naik'").getResultList();
			displayStudents(studentsList);
			studentsList = session.createQuery("from Student s where s.lastName='naik' or s.lastName='manjunath'").getResultList();
			displayStudents(studentsList);
			studentsList = session.createQuery("from Student s where s.email like '%@gmain.com'").getResultList();
			displayStudents(studentsList);
			session.getTransaction().commit();
			
			
			
		} catch (Exception e) {
		e.printStackTrace();	
		} finally {
			session.close();
		}

	}

	private static void displayStudents(List<Student> studentsList) {
		studentsList.forEach(s -> {
			System.out.println(s.toString());
		});
	}

}
