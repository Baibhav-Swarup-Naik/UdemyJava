package com.baibhav;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class UpdateStudentDemo {

	public static void main(String[] args) {
		SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml")
				.addAnnotatedClass(Student.class).buildSessionFactory();
		
		Session session = sessionFactory.getCurrentSession();
		try {
			//Fetch data from DB
			
			int studentId=1;
			session.beginTransaction();
	
			Student myStudent = session.get(Student.class,studentId );
			myStudent.setFirstName("Swarup");
			session.getTransaction().commit();
			
			session = sessionFactory.getCurrentSession();
			session.beginTransaction();
			System.out.println("Update email for all student");
			session.createQuery("update Student set email='abc@gmail.com'").executeUpdate();
			session.getTransaction().commit();
			System.out.println("Done");
			
			
		} catch (Exception e) {
		e.printStackTrace();	
		} finally {
			session.close();
		}

	}

	private static void displayStudents(List<Student> studentsList) {
		studentsList.forEach(s -> {
			System.out.println(s.toString());
		});
	}

}
