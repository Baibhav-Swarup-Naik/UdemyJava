package com.baibhav;

import java.sql.Connection;
import java.sql.DriverManager;

public class TestJdbc {

	public static void main(String[] args) {
		String jdbcUrl = "jdbc:mysql://localhost:3306/hibernate_demo?useSSL=false";
		String user = "root";
		String password = "Welcome@123";
		try {
			System.out.println("COnnecting to database: "+jdbcUrl);
			
			Connection con = DriverManager.getConnection(jdbcUrl,user,password);
			
			System.out.println("Connection successfull : "+con);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
