package com.baibhav.aop.aspect;

import java.util.List;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.baibhav.aop.Account;

@Aspect
@Order(2)
@Component
public class MyLoggingAspect {


	@Before("com.baibhav.aop.aspect.PointcutExpressionUtility.forDaoPackageNoGetterSetter()")
	public void beforeAddAccountAdvice(JoinPoint theJoinPoint) {
	System.out.println("\n===> Executing the @before advice on AddAccount()");	
	//Display the method signatue
	MethodSignature methodSig = (MethodSignature) theJoinPoint.getSignature();
	System.out.println("Method = "+methodSig);
	
	//display the method argument
	Object args[] = theJoinPoint.getArgs();
	
	for(Object tempArg : args) {
		System.out.println(tempArg);
		if(tempArg instanceof Account) {
			Account theAccount = (Account) tempArg;
			System.out.println("Account anme: "+theAccount.getName());
			System.out.println("Account level: "+theAccount.getLevel());
		}
	}
	}
	
	
	@AfterReturning(pointcut="execution(* com.baibhav.aop.dao.AccountDAO.findAccount(..))",returning="result")
	public void afterReturningFindAccountsAdvice(JoinPoint theJoinPoint,List<Account> result) {
		
		
		String method = theJoinPoint.getSignature().toString();
		System.out.println("==> executing @aferreturning method "+method);
		
		System.out.println("==> executing @aferreturning result "+result);
		converAccountNamesToUpperCase(result);
		System.out.println("==> executing @aferreturning result after converting to uppercase "+result);
	}


	private void converAccountNamesToUpperCase(List<Account> result) {
		// TODO Auto-generated method stub
		for(Account temp: result) {
			String upperCaseName = temp.getName().toUpperCase();
			temp.setName(upperCaseName);
		}
		
	}
	
	
	@AfterThrowing(pointcut="execution(* com.baibhav.aop.dao.AccountDAO.findAccount(..))",throwing="ex")
	public void afterThrowingFindAccountAdvice(JoinPoint theJoinPoint,Throwable ex) {
		
		String method = theJoinPoint.getSignature().toString();
		System.out.println("==> executing @AfterThrowing method "+method);
		System.out.println("==> Exception in @AfterThrowing on method: "+ex);
	}
	
	
	
}
