package com.baibhav.aop;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.baibhav.aop.dao.AccountDAO;
import com.baibhav.aop.dao.MembershipDAO;

public class AfterThrowingDemoApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(DemoConfig.class);
		AccountDAO accountDAO = context.getBean("accountDAO",AccountDAO.class);
		List<Account> myAccounts = null;
		try {
			boolean tripWire  = true;
			myAccounts = accountDAO.findAccount(tripWire);
		} catch (Exception e) {
			System.out.println("Exception caught in main app"+e);
		}
		
		System.out.println("In main after throwing return");
		System.out.println(myAccounts);
		context.close();
		
	}

}
