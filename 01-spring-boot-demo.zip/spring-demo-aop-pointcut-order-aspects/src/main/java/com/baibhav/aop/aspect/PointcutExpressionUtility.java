package com.baibhav.aop.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;
@Aspect
@Component
public class PointcutExpressionUtility {

	
	
	@Pointcut("execution (* com.baibhav.aop.dao.*.*(..))")
	public void forDaoPackage() {}
	
	@Pointcut("execution (* com.baibhav.aop.dao.*.get*(..))")
	public void getter() {}
	
	@Pointcut("execution (* com.baibhav.aop.dao.*.set*(..))")
	public void setter() {}
	
	@Pointcut("forDaoPackage() && !(getter() || setter())")
	public void forDaoPackageNoGetterSetter() {}
	

}
