package com.baibhav.aop.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class MyLoggingAspect {

	
	@Pointcut("execution (* com.baibhav.aop.dao.*.*(..))")
	private void forDaoPackage() {}
	
	@Pointcut("execution (* com.baibhav.aop.dao.*.get*(..))")
	private void getter() {}
	
	@Pointcut("execution (* com.baibhav.aop.dao.*.set*(..))")
	private void setter() {}
	
	@Pointcut("forDaoPackage() && !(getter() || setter())")
	private void forDaoPackageNoGetterSetter() {}
	

	@Before("forDaoPackageNoGetterSetter()")
	public void beforeAddAccountAdvice() {
	System.out.println("\n===> Executing the @before advice on AddAccount()");	
	}
	
	@Before("forDaoPackageNoGetterSetter()")
	public void performApiAnalytics() {
	System.out.println("\n===> performApiAnalytics");	
	}
	
}
