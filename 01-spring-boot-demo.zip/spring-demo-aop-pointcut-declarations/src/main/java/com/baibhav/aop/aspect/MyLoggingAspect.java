package com.baibhav.aop.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class MyLoggingAspect {

//	@Before("execution (public void addAccount())")
//	@Before("execution (public void com.baibhav.aop.dao.AccountDAO.addAccount())")
	@Before("execution (* com.baibhav.aop.dao.MembershipDAO.*(..))")
	public void beforeAddAccountAdvice() {
	System.out.println("\n===> Executing the @before advice on AddAccount()");	
	}
	
}
