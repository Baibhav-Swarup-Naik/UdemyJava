package com.baibhav;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AnnotationBeanScopeDemoApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				//read spring config file
				ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("ApplicationContext.xml");
				
				//get the bean from spring container
				Coach theCoach = context.getBean("tennisCoach",Coach.class);
				Coach alphaCoach = context.getBean("tennisCoach",Coach.class);
				
				boolean result = (theCoach == alphaCoach);
				System.out.println("is theCoach & alphaCOach pointing to same memory location: "+result);
				System.out.println("theCoach: "+theCoach);
				System.out.println("alphaCoach: "+alphaCoach);
				
				context.close();
	}
}
