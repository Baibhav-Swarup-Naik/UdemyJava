package com.baibhav;

public interface Coach {

	public String getDailyWorkout();
	public String getDailyFortune();
}
