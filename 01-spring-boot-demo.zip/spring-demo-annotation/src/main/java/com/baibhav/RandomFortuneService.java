package com.baibhav;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class RandomFortuneService implements FortuneService {

	@Value("${foo.randomFortune}")
	String randomFortune;
	
	String output;
	@PostConstruct
	public void setValuesFromFile () {
		output = randomFortune;
	}
	
	@Override
	public String getFortune() {
		// TODO Auto-generated method stub
		return output;
	}

}
