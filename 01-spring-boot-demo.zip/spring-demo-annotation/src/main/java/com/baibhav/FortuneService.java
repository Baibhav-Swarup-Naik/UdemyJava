package com.baibhav;

public interface FortuneService {

	public String getFortune();
}
