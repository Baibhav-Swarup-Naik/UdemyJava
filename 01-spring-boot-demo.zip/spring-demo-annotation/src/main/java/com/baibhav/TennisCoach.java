package com.baibhav;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.util.SystemPropertyUtils;

@Component
public class TennisCoach implements Coach {

	@Autowired
	@Qualifier("randomFortuneService")
	private FortuneService fortuneService;
	
	//COnstructor injection using autowire annotation
	/*@Autowired
	public TennisCoach(FortuneService fortuneService) {
		super();
		System.out.println("Constroctor method of TennisCoach");
		this.fortuneService = fortuneService;
	}
*/
	//Setter method injection using autowire
	/*@Autowired
	public void setFortuneService(FortuneService fortuneService) {
		System.out.println("Setter method of TennisCoach");
		this.fortuneService = fortuneService;
	}*/
	
	//Any random method dependency injection using autowire
/*	@Autowired
	public void anyMethod(FortuneService fortuneService) {
		System.out.println("anyMethod()  of TennisCoach");
		this.fortuneService = fortuneService;
	}*/
	
	public TennisCoach() {
		System.out.println("Default construtor of TennisCoach");
	}
	
	//define init method
	@PostConstruct
	public void doMyStatupStuff() {
		System.out.println("inside doMyStatupStuff()");
	}
	
	//define destroy method
	@PreDestroy
	public void doMyCLeanupStuff() {
		System.out.println("inside doMyCLeanupStuff()");
	}
	
	@Override
	public String getDailyWorkout() {
		// TODO Auto-generated method stub
		return "Practice your backhand volley";
	}

	@Override
	public String getDailyFortune() {
		// TODO Auto-generated method stub
		return fortuneService.getFortune();
	}

}
