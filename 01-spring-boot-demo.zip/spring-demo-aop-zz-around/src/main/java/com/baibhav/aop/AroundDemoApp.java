package com.baibhav.aop;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.baibhav.aop.dao.AccountDAO;
import com.baibhav.aop.dao.MembershipDAO;
import com.baibhav.aop.service.TrafficFortuneService;

public class AroundDemoApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(DemoConfig.class);
		TrafficFortuneService theFortunService = context.getBean("trafficFortuneService",TrafficFortuneService.class);
		
		System.out.println("Main program : AroundDemoApp");
		System.out.println("Callig getFortune()");
		String data = theFortunService.getFortune();
		System.out.println("my fortune is: "+data);
		System.out.println("Finished");
		context.close();
		
	}

}
