console.log('Hello World!!!!');
var first = 'John';
var age = 25;
var fullage = true;
console.log(first+ ' '+age);
age=30
console.log(age);
console.log(fullage);
var lastname = prompt('Tell the last name');
alert(first +' '+lastname);
console.log(typeof age);
