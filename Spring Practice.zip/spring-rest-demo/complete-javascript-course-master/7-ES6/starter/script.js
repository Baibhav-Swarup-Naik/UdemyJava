//ES5
var name5 = 'jane smith';
var age5 = 25;
name5 = 'jane miller';
console.log(name5);

//ES6
const name6 = 'jane smith';
let age6 = 25;
//name6 = 'jane miller'; //error
console.log(name6);

//ES5
function driverLicense5(passedTest) {
    if (passedTest) {
        //    console.log(firstname);//undefined
        var firstname = 'john';
        var yearOfBirth = 1995;
        //   console.log(firstname + ' born in ' + yearOfBirth + ' allowed to drive');
    }
    console.log(firstname + ' born in ' + yearOfBirth + ' allowed to drive');
}
driverLicense5(true);

//ES6
function driverLicense6(passedTest) {
    //   console.log(firstname); //error
    let firstname;
    const yearOfBirth = 1995;
    if (passedTest) {
        firstname = 'john';

        //  console.log(firstname + ' born in ' + yearOfBirth + ' allowed to drive');
    }
    console.log(firstname + ' born in ' + yearOfBirth + ' allowed to drive');
}
driverLicense6(true);

let i = 23;
for (let i = 0; i < 5; i++) {
    console.log(i);
}
console.log(i);


